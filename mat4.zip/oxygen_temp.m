Temp=[15,10,15,20,25,30,35,40,45];
oxygen=[0.01,0.04,0.10,0.20,0.25,0.28,0.30,0.25,0.02];
Growth.Temp=Temp;
Growth.oxygen=oxygen;
plot(oxygen,Temp);
xlabel('oxygen(g)')
ylabel('temp(oc)')
title('oxygen uptake rate')
grid on