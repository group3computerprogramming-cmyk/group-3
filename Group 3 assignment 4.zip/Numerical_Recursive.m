clear
clc
% Purpose: Solves the reaction rate equation x-sinx= 0 using two different numerical methods and verifies the solutions
function reaction_rate_solver()
    % Display program header
    fprintf('=== Reaction Rate Equation Solver ===\n');
    fprintf('Solving: x-sinx = 0\n\n');
    
    tol = 1e-6;        % Tolerance for convergence (stop when |f(x)| < tol)
    max_iter = 100;    % Maximum number of iterations to prevent infinite loops
    
    % NEWTON-RAPHSON METHOD SECTION
    fprintf('1. NEWTON-RAPHSON METHOD\n');
    x0_newton = 2;   % Initial guess for Newton-Raphson method
    % Call recursive Newton-Raphson solver
    root_newton = newton_recursive(x0_newton, tol, max_iter);
    fprintf('   Root: %.8f\n', root_newton);
    
    % SECANT METHOD SECTION  
    fprintf('\n2. SECANT METHOD\n');
    x0_secant = 4;   % First initial guess for Secant method
    x1_secant = 6;   % Second initial guess for Secant method
    % Call recursive Secant solver
    root_secant = secant_recursive(x0_secant, x1_secant, tol, max_iter);
    fprintf('   Root: %.8f\n', root_secant);

    % VERIFICATION SECTION
    fprintf('\n3. VERIFICATION\n');
    % Verify both solutions by plugging back into original equation
    verify_solution(root_newton, 'Newton-Raphson');
    verify_solution(root_secant, 'Secant');
    
    fprintf('\n=== Solution Complete ===\n');
end

% NEWTON-RAPHSON RECURSIVE FUNCTION
% Inputs: x - current estimate of root
%         tol - tolerance for convergence
%         max_iter - maximum allowed iterations
%         iter - current iteration count (optional, for internal use)
% Output: root - the found root of the equation
function root = newton_recursive(x, tol, max_iter, iter)
    % If iter not provided, initialize to 1 (first call)
    if nargin < 4
        iter = 1;
    end
    % Safety check: prevent infinite recursion
    if iter > max_iter
        error('Newton: Maximum iterations reached');
    end
    
    % FUNCTION EVALUATION
    f = x-sinx;           % Evaluate f(x) = x-sinx
    f_prime = 1-cosx;       % Evaluate f'(x) = 1-cosx (derivative)
    
    % CONVERGENCE CHECK
    if abs(f) < tol
        fprintf('   Converged in %d iterations', iter);
        root = x;  % Return current x as root if converged
        return;
    end

    % NEWTON-RAPHSON UPDATE FORMULA
    % x_new = x_old - f(x_old)/f'(x_old)
    x_new = x - f / f_prime;
    
    % Recursive call with updated estimate
    root = newton_recursive(x_new, tol, max_iter, iter + 1);
end

% SECANT RECURSIVE FUNCTION
% Inputs: x0, x1 - two previous estimates of root
%         tol - tolerance for convergence  
%         max_iter - maximum allowed iterations
%         iter - current iteration count (optional, for internal use)
% Output: root - the found root of the equation
function root = secant_recursive(x0, x1, tol, max_iter, iter)
    % If iter not provided, initialize to 1 (first call)
    if nargin < 5
        iter = 1;
    end
    
    % Safety check: prevent infinite recursion
    if iter > max_iter
        error('Secant: Maximum iterations reached');
    end
   
    % FUNCTION EVALUATIONS
    f0 = x0 -sinx0;  % Evaluate f(x0)
    f1 = x1 -sinx1;  % Evaluate f(x1)
    
    % CONVERGENCE CHECK
    if abs(f1) < tol
        fprintf('   Converged in %d iterations', iter);
        root = x1;  % Return current x1 as root if converged
        return;
    end

    % SECANT METHOD UPDATE FORMULA
    % x2 = x1 - f(x1) * (x1 - x0) / (f(x1) - f(x0))
    x2 = x1 - f1 * (x1 - x0) / (f1 - f0);
    
    % Recursive call with updated estimates (shift x0, x1 forward)
    root = secant_recursive(x1, x2, tol, max_iter, iter + 1);
end

% VERIFICATION FUNCTION
% Purpose: Verifies that the found root actually satisfies the equation
% Inputs: root - the root to verify
%         method_name - name of the method used (for display purposes)
function verify_solution(root, method_name)
    % Plug the root back into the original equation
    f_val = root^3 - root - 3;
    % Display result: should be very close to 0 if root is accurate
    fprintf('   %s: f(%.8f) = %.2e\n', method_name, root, f_val);
end
% This line actually runs the solver when the script is executed
reaction_rate_solver();